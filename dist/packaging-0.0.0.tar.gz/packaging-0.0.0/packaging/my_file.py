from packaging.my_other_file import CONSTANT
from my_folder import A
from my_folder.my_nested_file import CONSTANT as CONSTANT2

print(CONSTANT)
print(CONSTANT2)
print(A)
