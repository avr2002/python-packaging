from packaging.my_other_file import CONSTANT as CONST
from packaging.my_folder.my_sub_package.nested_module import add

CONSTANT = "HELLO"

print(CONST)
print(add(1, 2))
