def add(x: float, y: float) -> float:
    """
    Adds two numbers.
    """
    return x + y


def subtract(x: float, y: float) -> float:
    """
    subtracts two numbers.
    """
    return x - y
